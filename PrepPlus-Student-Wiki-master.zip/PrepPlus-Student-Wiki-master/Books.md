# Books

We all know that good books are hard to find when it comes to programming. I have used a few books as references throughout my journey of learning how to program. I have created a folder on dropbox that contains the books that used. Feel free to download. There is more to come:

* [Books Galore](https://www.dropbox.com/sh/sdgisz92qt780zi/AAAFQCLZbxqEZlEum4iHFAeVa?dl=0)