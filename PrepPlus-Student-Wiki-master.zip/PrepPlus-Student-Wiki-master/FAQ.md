#TGP+ Student FAQ

###What if I don’t finish the PreCourse?

Our recommendation is to push to the next cohort. It's going to be tough for you to get the most out of the course without getting through the precourse first. It's not impossible, but there's a good chance the information will be overwhelming without being introduced to the basic fundamentals.

In rare cases we let students should try it for a week, and gauge whether they should continue. We have a self-assessment on the first Thursday that will give us, and you, a good understanding about if you should continue with the course.
