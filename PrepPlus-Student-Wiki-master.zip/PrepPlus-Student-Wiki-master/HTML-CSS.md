# HTML and CSS


I know some of you never dealt with HTML or CSS before. Both are great to learn and you will definitely have to face both in the industry. It does not hurt to learn the basics. Though Javascript should be your focus. I included some resources below for you to take a look at:


 * [Learn HTML & CSS](http://learn.shayhowe.com/html-css/)

 * [HTML5 & CSS3 Fundamentals](https://mva.microsoft.com/en-US/training-courses/html5-css3-fundamentals-development-for-absolute-beginners-14207?l=Y4COscFfB_7500115888)

 * [Mark Sheet](http://marksheet.io/)

 * [Codecademy](https://www.codecademy.com/learn/web)

 * [Code Avengers](https://www.codeavengers.com/)

 * [CSS Diner](http://flukeout.github.io/#)
